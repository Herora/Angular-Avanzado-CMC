# Loopback 3, Angular 6 & Bootstrap 4
Hola y bienvenido. 

En este repo, encontrarás el código del proyecto de Loopback 3, Angular 6 & Bootstrap 4. 
En la rama master está TODO el proyecto, si solo quieres ver el back en Loopback, <code> git ckeckout ApiLoopback </code>

Y si quieres ver como hice este proyecto, aquí te dejo el link de los videos. 
https://www.youtube.com/playlist?list=PL_9MDdjVuFjGJm9hBCwIb2nkLYIf83o2A

Facebook: https://www.facebook.com/dominicodee/

Twitter : https://twitter.com/domini_code

Suscribete al canal: https://www.youtube.com/c/DominiCode

Visita nuestra web: https://dominicode.com/


